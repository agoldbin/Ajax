$(document).ready(function() {
    $(document).tooltip();
    $("#inputBirthdate").datepicker({
        changeMonth: true,
        changeYear: true
    });
})
