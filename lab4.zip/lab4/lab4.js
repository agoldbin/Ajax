function init() {
// Set up onclick event handler, w3c. Use addEventListener
var btnSet3 = document.getElementById("btns3");
// console.log(btnSet3.children);
btnSet3.addEventListener("click", function(event) {
    if (btnSet3 !== event.target) {
        w3c(event.target.value);
    }
});
}

function dotNotation(btnValue) {
    console.log(btnValue);
}

function w3c(btns3) {
    console.log(btns3);
}
